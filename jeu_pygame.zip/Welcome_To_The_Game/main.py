import pygame
import sys
import time
# from music import Music
from Joueur import Plheyer
from monstre import Monstre

pygame.init()


# Classe jeu

class Game:

    def __init__(self, fenetre):
        # generation joueur
        self.player = Plheyer(10, 590)
        self.fenetre = fenetre
        self.bg = pygame.image.load('assets/bg.png')
        self.bg = pygame.transform.scale(self.bg, (1080, 720))
        self.pressed = {}
        # Autre
        self.font = pygame.font.Font('assets/myfont.TTF', 30)
        self.monstre = []
        self.timer = time.time()
        # self.music = Music()

    # Draw
    def draw(self):
        # Joueur
        self.fenetre.blit(self.bg, (0, 0))
        self.fenetre.blit(self.player.image_vie, (960, 10))
        vie = self.font.render(str(self.player.health), 1, (255, 255, 255))
        self.fenetre.blit(vie, (1000, 10))

        # Monstre
        for n in game.monstre:
            n.draw(self.fenetre)
            n.move()


    def gen_monstre(self):
        d=Monstre()
        self.monstre.append(d)


# Generer la fenetre de notre jeu
pygame.display.set_caption("Platforme")
screen = pygame.display.set_mode((1080, 720))

# charger notre jeu
game = Game(screen)

# Sprites creation
moving_sprites = pygame.sprite.Group()
moving_sprites.add(game.player)
var = game.player.frame

# Charger le joueur
# player = Plheyer(10,10)

running = True

# Boucle tant que "running" est "true"
while running:

    # game.music.play("music")

    clock = pygame.time.Clock()
    FPS=60
    clock.tick(FPS)
    # genere les monstres
    if time.time() - game.timer >= 4:
        game.timer = time.time()
        game.gen_monstre()

    # mouvement à droite
    if game.pressed.get(pygame.K_RIGHT):
        game.player.rect.x += 10
        game.player.animate_right()

    # mouvement à gauche
    if game.pressed.get(pygame.K_LEFT):
        game.player.rect.x -= 10
        game.player.animate_left()

    #collision avec un monstre
    for k in game.monstre:
        if game.player.x==k.x:
            game.player.health -= 1
        elif game.player.health==0:
            pygame.quit()
            sys.exit()


    # Saut du joueur
    if game.pressed.get(pygame.K_SPACE):
        game.player.y -= 80
        clock = pygame.time.Clock()
        clock.tick(500)
        game.player.y += 80

    # si le joueur ferme le jeu
    for event in pygame.event.get():
        # si l'event est la fermeture
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

        # mouvement
        elif event.type == pygame.KEYDOWN:
            game.pressed[event.key] = True

        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False

    # Drawing
    moving_sprites.draw(screen)
    moving_sprites.update()
    pygame.display.flip()
    clock.tick(var)

    game.draw()

