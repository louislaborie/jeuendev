import pygame
import time

pygame.init()

clock = pygame.time.Clock()


class Plheyer(pygame.sprite.Sprite):

    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.health = 8
        self.image_vie = pygame.image.load('assets/coeur.png')
        self.image_vie = pygame.transform.scale(self.image_vie, (100, 100))
        # Personnage
        self.x = pos_x
        self.y = pos_y
        # Sprite
        # droite
        self.is_animating_right = False
        self.sprites_right = []
        self.sprites_right.append(pygame.image.load('assets/GIF/yoshi_1.png'))
        self.sprites_right.append(pygame.image.load('assets/GIF/yoshi_2.png'))
        # gauche
        self.is_animating_left = False
        self.sprites_left = []
        self.sprites_left.append(pygame.image.load('assets/GIF/yoshi_4.png'))
        self.sprites_left.append(pygame.image.load('assets/GIF/yoshi_3.png'))
        # sprite
        self.current_sprite = 0
        self.image = self.sprites_right[self.current_sprite]
        self.frame = clock.tick(-10)

        self.rect = self.image.get_rect()
        self.rect.topleft = [pos_x, pos_y]

    def animate_right(self):
        self.is_animating_right = True

    def animate_left(self):
        self.is_animating_left = True

    def update(self):
        if self.is_animating_right:
            self.current_sprite += 1

            if self.current_sprite >= len(self.sprites_right):
                self.current_sprite = 0
                self.is_animating_right = False

            self.image = self.sprites_right[self.current_sprite]

        if self.is_animating_left:
            self.current_sprite += 1

            if self.current_sprite >= len(self.sprites_left):
                self.current_sprite = 0
                self.is_animating_left = False

            self.image = self.sprites_left[self.current_sprite]

    # clock.tick(500)

    def move_right(self):
        self.x += 7

    def move_left(self):
        self.x -= 7
