import pygame

class Music():

    def __init__(self):
        self.sound = {
            'music' : pygame.mixer.Sound("assets/a.mp3"),
        }

    def play(self,name):
        self.sound[name].play()