import pygame
pygame.init()

class Monstre:

    def __init__(self):
        self.width = 85
        self.height = 85
        self.image = pygame.image.load('assets/monstre1.png')
        self.image = pygame.transform.scale(self.image,(self.width,self.height))
        self.x = 1150
        self.y = 610
        self.rect=self.image.get_rect()

    def draw(self,fenetre):
        fenetre.blit(self.image,(self.x, self.y))

    def move(self):
        self.x -= 5