import pygame
from main import Game
pygame.init()

class Main_Menu:

    def __init__(self):
        pass

    def draw(self):
        pass


main_menu = Main_Menu()

pygame.display.set_caption("Platforme")
screen = pygame.display.set_mode((1080, 720))

running = True

while running:

    # si le joueur ferme le jeu
    for event in pygame.event.get():
        # si l'event est la fermeture
        if event.type == pygame.QUIT:
            running = False
            pygame.quit
        # mouvement
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                running = False
                game = Game()
                game.run()
                del game

    Main_Menu.draw()

    # maj fenetre
    pygame.display.flip()